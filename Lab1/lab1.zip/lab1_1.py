import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statistics
import csv

files = {
    '1-Coev-RS': {'filename': 'cel-rs.csv', 'color': '#00ff00'},
    '1-Coev': { 'filename': 'cel.csv', 'color': '#000000' },
    '1-Evol-RS': { 'filename': 'rsel.csv', 'color': '#0000ff'},
    '2-Coev': { 'filename': '2cel.csv', 'color': '#ff8da1'},
    '2-Coev-RS': { 'filename': '2cel-rs.csv', 'color': '#ff0000' }
}

folder_with_data = './'

plt.figure(figsize=(6.7, 6.7))
plt.tick_params(top=True, right=True, bottom=True, left=True, direction='in')

for name_of_algorithm, subData in files.items():
    nameOfDataset = subData['filename']
    color = subData['color']
        
    with open(f'{folder_with_data}/{nameOfDataset}') as file:
        columns, *data = list(csv.reader(file))
        columns = dict(map(reversed, enumerate(columns)))
        data = list(map(lambda x: list(map(float, x)), data))
        x = list(map(lambda x: x[columns['effort']], data))
        y = list(map(lambda x: statistics.mean(x[2:]), data))
        plt.plot(x, y, label=name_of_algorithm, linewidth=0.9, color=color)

plt.xlabel('Rozegranych gier')
plt.ylabel('Odsetek wygranych gier')
plt.legend(fontsize='xx-large', loc='lower right', fancybox=False)
plt.show()










